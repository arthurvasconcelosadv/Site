# ⚖️ Site — Advogado Trabalhista Uberlândia

Site profissional completo para advocacia trabalhista.  
Pronto para publicação. Basta personalizar e fazer o deploy.

---

## 📁 Estrutura do Projeto

```
advogado-trabalhista/
├── index.html              # Home — página principal
├── sobre.html              # Sobre o advogado
├── contato.html            # Contato + formulário WhatsApp
├── uberlandia.html         # SEO local Uberlândia/MG
├── online.html             # Atendimento online nacional
├── privacidade.html        # Política de Privacidade (LGPD)
├── 404.html                # Página de erro personalizada
├── sitemap.xml             # Mapa do site para Google
├── robots.txt              # Instruções para robôs de busca
├── manifest.json           # PWA — instalar como app
├── favicon.svg             # Ícone do site
├── netlify.toml            # Configuração de hospedagem (Netlify)
│
├── css/
│   └── style.css           # Todo o CSS do site
│
├── js/
│   └── main.js             # Interatividade: menu, FAQ, formulário
│
├── areas/
│   ├── insalubridade.html
│   ├── demissao.html
│   ├── jornada.html
│   ├── assedio.html
│   └── acidente.html
│
├── blog/
│   ├── index.html
│   ├── rescisao-indireta.html
│   ├── insalubridade.html
│   ├── assedio-moral.html
│   ├── acidente-trabalho.html
│   └── horas-extras.html
│
└── images/                 # Adicionar suas fotos aqui
    ├── foto-advogado.jpg   # Foto profissional (recomendado 400x500px)
    ├── og-home.jpg         # Imagem para redes sociais (1200x630px)
    ├── icon-192.png        # Ícone PWA
    └── icon-512.png        # Ícone PWA grande
```

---

## 🔧 PERSONALIZAÇÃO OBRIGATÓRIA

Antes de publicar, faça as seguintes substituições em **todos os arquivos HTML**:

| Placeholder | Substituir por |
|---|---|
| `[Seu Nome]` | Seu nome completo (ex: João Silva) |
| `[Nº OAB]` / `[XXXX]` | Número da sua inscrição na OAB/MG |
| `5534999999999` | Seu WhatsApp: `55` + DDD + número (sem espaços) |
| `seuadvogado.com.br` | Seu domínio real |
| `contato@seuadvogado.com.br` | Seu e-mail profissional |
| `Av. João Pinheiro, 100, Sala 201` | Seu endereço real |

### Como fazer em massa (terminal):

```bash
# Substituir em todos os arquivos HTML de uma vez
find . -name "*.html" -exec sed -i 's/\[Seu Nome\]/João Silva/g' {} \;
find . -name "*.html" -exec sed -i 's/5534999999999/5534912345678/g' {} \;
find . -name "*.html" -exec sed -i 's/seuadvogado\.com\.br/joaosilvaadv.com.br/g' {} \;
```

---

## 🚀 DEPLOY — Passo a Passo

### Opção 1: Netlify (Recomendado — Grátis)

1. Acesse [netlify.com](https://netlify.com) e crie uma conta gratuita
2. No painel, clique em **"Add new site" → "Deploy manually"**
3. **Arraste a pasta inteira** `advogado-trabalhista/` para a área de upload
4. O site vai ao ar instantaneamente com um URL temporário
5. Conecte seu domínio: **Domain management → Add custom domain**

### Opção 2: Vercel (Alternativa grátis)

```bash
npm install -g vercel
cd advogado-trabalhista
vercel --prod
```

### Opção 3: GitHub + Netlify (Recomendado para atualizações frequentes)

```bash
git init
git add .
git commit -m "Site inicial"
git remote add origin https://github.com/seuuser/seurepositorio.git
git push -u origin main
```
Depois conecte o repositório no painel do Netlify — atualizações automáticas a cada commit.

---

## 🌐 DOMÍNIO

### Onde registrar:
- **registro.br** — `.com.br` por ~R$ 40/ano (recomendado)
- **GoDaddy / Namecheap** — `.com` por ~R$ 50/ano

### Sugestões de domínio:
- `advogadotrabalhista-uberlandia.com.br`
- `[seunome]trabalhista.com.br`
- `[seunome]advogado.com.br`

### Configurar DNS no Netlify:
1. Copie os nameservers do Netlify (ex: `dns1.p05.nsone.net`)
2. Acesse seu registrador (registro.br)
3. Substitua os nameservers pelos do Netlify
4. Aguarde até 48h para propagação

---

## 📊 GOOGLE SEARCH CONSOLE

1. Acesse [search.google.com/search-console](https://search.google.com/search-console)
2. Clique em **"Adicionar propriedade"** → escolha **"Domínio"**
3. Adicione o registro TXT no DNS (o Google mostra exatamente como)
4. Após verificação, vá em **"Sitemaps"** e envie: `https://seudominio.com.br/sitemap.xml`
5. Solicite indexação da home clicando em **"Inspecionar URL"** → **"Solicitar indexação"**

---

## 📍 GOOGLE MEU NEGÓCIO (OBRIGATÓRIO para SEO local)

Esta é a ação com **maior impacto no curto prazo** para aparecer nas buscas locais de Uberlândia.

1. Acesse [business.google.com](https://business.google.com)
2. Clique em **"Adicionar negócio"**
3. Preencha:
   - **Nome:** `Dr. [Seu Nome] — Advogado Trabalhista`
   - **Categoria:** `Advogado` + `Serviço jurídico`
   - **Endereço:** endereço do escritório
   - **Horário:** segunda a sexta, 8h–18h
   - **Telefone:** seu WhatsApp
   - **Site:** seu domínio
4. Faça verificação pelo correio (Google envia cartão postal)
5. Adicione **fotos do escritório** e **foto profissional**
6. Peça a clientes satisfeitos que deixem avaliações — **isso é ouro para o SEO local**

---

## 📅 PLANO DE RANQUEAMENTO — 30 DIAS

| Semana | Ação | Impacto |
|---|---|---|
| 1 | Publicar site + Search Console + Google Meu Negócio | Alto |
| 1 | Verificar indexação da home e das 5 páginas de área | Alto |
| 2 | Pedir avaliações no Google para 5–10 clientes antigos | Muito Alto |
| 2 | Criar perfil no JusBrasil com link para o site | Médio |
| 3 | Compartilhar artigos do blog em grupos de WhatsApp e LinkedIn | Médio |
| 3 | Cadastrar em diretórios: OAB online, Advogado.com, Doctoralia | Médio |
| 4 | Publicar 1 novo artigo no blog sobre tema local | Alto |
| 4 | Solicitar link do site de algum parceiro (contador, sindicato, etc.) | Alto |

---

## 🔗 BACKLINKS — Fontes de Alta Qualidade

Para subir no Google, consiga links destas fontes:

1. **JusBrasil** — Crie perfil profissional e publique artigos jurídicos com link para o site
2. **LinkedIn** — Artigos e posts com link para o blog
3. **OAB/MG** — Verifique se há diretório de advogados com link
4. **Sindicatos locais** — Parcerias com sindicatos de trabalhadores de Uberlândia
5. **Portais locais** — Uberlândia Web, G1 Uberlândia (por meio de press release)
6. **Contadores e RHs** — Parcerias que referenciem seu site

---

## 📈 GOOGLE ANALYTICS 4

Para monitorar visitas, adicione antes de `</head>` em todas as páginas:

```html
<!-- Google Analytics 4 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

Substitua `G-XXXXXXXXXX` pelo seu ID do Google Analytics.

---

## 💡 PERSONALIZAÇÕES EXTRAS RECOMENDADAS

### Adicionar foto do advogado (sobre.html)
Substitua o bloco com emoji `⚖️` por:
```html
<img src="images/foto-advogado.jpg" 
     alt="Dr. [Seu Nome] — Advogado Trabalhista Uberlândia"
     style="width:100%;height:100%;object-fit:cover;border-radius:var(--radius-lg);"/>
```

### Adicionar imagem Open Graph (redes sociais)
Crie uma imagem `1200x630px` com fundo navy, nome e slogan, salve como `images/og-home.jpg`.

### Adicionar número de WhatsApp correto
Substitua `5534999999999` em todos os arquivos pelo formato:
`55` (Brasil) + `34` (DDD Uberlândia) + número (9 dígitos)

Exemplo: WhatsApp `(34) 9 8765-4321` → `5534987654321`

---

## ⚖️ CONFORMIDADE OAB

O site já inclui:
- ✅ Nota de rodapé: "Site com caráter informativo. Não constitui consulta jurídica."
- ✅ Menção ao Estatuto da OAB (Lei 8.906/94)
- ✅ Sem promessa de resultado
- ✅ Sem publicidade comparativa
- ✅ Política de Privacidade (LGPD)

Verifique também as normas específicas do **Código de Ética e Disciplina da OAB** para publicidade na advocacia (Provimento 205/2021).

---

## 🆘 SUPORTE

Dúvidas sobre personalização ou deploy?  
Este README cobre todos os casos. Boa sorte com o ranqueamento!
